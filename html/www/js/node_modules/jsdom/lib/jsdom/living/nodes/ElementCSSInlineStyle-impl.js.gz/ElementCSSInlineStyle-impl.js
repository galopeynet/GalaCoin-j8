"use strict";

class ElementCSSInlineStyle { }

module.exports = {
  implementation: ElementCSSInlineStyle
};

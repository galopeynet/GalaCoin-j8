"use strict";

const HTMLTableCellElementImpl = require("./HTMLTableCellElement-impl").implementation;

class HTMLTableHeaderCellElementImpl extends HTMLTableCellElementImpl { }

module.exports = {
  implementation: HTMLTableHeaderCellElementImpl
};

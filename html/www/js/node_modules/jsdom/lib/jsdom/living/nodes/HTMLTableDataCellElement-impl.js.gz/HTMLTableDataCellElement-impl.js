"use strict";

const HTMLTableCellElementImpl = require("./HTMLTableCellElement-impl").implementation;

class HTMLTableDataCellElementImpl extends HTMLTableCellElementImpl { }

module.exports = {
  implementation: HTMLTableDataCellElementImpl
};

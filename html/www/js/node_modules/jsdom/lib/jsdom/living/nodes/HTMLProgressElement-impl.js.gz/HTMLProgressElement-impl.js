"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLProgressElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLProgressElementImpl
};

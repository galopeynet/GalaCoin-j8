"use strict";

exports.implementation = class NavigatorPluginsImpl {
  javaEnabled() {
    return false;
  }
};

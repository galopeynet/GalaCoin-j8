"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLModElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLModElementImpl
};

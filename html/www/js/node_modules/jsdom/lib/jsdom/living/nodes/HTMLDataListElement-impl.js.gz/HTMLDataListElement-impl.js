"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLDataListElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLDataListElementImpl
};

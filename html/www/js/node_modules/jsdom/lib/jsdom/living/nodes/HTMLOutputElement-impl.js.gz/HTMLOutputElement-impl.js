"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLOutputElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLOutputElementImpl
};

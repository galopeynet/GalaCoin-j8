"use strict";
const EventImpl = require("./Event-impl").implementation;

exports.implementation = class FocusEventImpl extends EventImpl { };

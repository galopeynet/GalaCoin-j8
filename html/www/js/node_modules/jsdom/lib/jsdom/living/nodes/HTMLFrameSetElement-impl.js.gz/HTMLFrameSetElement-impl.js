"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLFramesetElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLFramesetElementImpl
};

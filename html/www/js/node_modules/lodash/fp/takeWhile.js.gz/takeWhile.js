var convert = require('./convert'),
    func = convert('takeWhile', require('../takeWhile'));

func.placeholder = require('./placeholder');
module.exports = func;

var convert = require('./convert'),
    func = convert('dropRight', require('../dropRight'));

func.placeholder = require('./placeholder');
module.exports = func;

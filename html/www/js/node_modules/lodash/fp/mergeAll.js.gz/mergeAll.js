var convert = require('./convert'),
    func = convert('mergeAll', require('../merge'));

func.placeholder = require('./placeholder');
module.exports = func;

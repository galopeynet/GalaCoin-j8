var convert = require('./convert'),
    func = convert('merge', require('../merge'));

func.placeholder = require('./placeholder');
module.exports = func;
